package com.cruds.demo.mvndemo;

public class Calculator {

	public int subtract(int x, int y)
	{
		return x - y;
	}
	
	
}
